library(testthat)
# library(NetworkExposure)

test_check("NetworkExposure")
